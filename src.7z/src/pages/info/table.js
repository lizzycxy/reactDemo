import React from "react";
import TableItem from "../../component/tableItem";
class Table extends React.Component{
    render(){
        return(
            <TableItem />
        )
    }
}

export default Table;