import React from "react";
import LineMarkerEcharts from "../../component/echart";

class Echarts extends React.Component{
    render() {
        return(
            <LineMarkerEcharts />
        )
    }
}

export default Echarts;